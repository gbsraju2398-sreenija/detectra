(function () {
  'use strict';

  /* ------------------------------------------------------------------
     Media rules
     ------------------------------------------------------------------ */
  var MB = 1024 * 1024;
  var KINDS = {
    image: {
      max: 20 * MB, names: 'JPG, PNG, WebP',
      exts: ['jpg', 'jpeg', 'png', 'webp'],
      mimes: ['image/jpeg', 'image/png', 'image/webp']
    },
    video: {
      max: 100 * MB, names: 'MP4, MOV, WebM',
      exts: ['mp4', 'mov', 'webm'],
      mimes: ['video/mp4', 'video/quicktime', 'video/webm']
    }
  };
  var TYPE_LABELS = {
    jpg: 'JPEG image', jpeg: 'JPEG image', png: 'PNG image', webp: 'WebP image',
    mp4: 'MP4 video', mov: 'QuickTime video', webm: 'WebM video'
  };
  var STEPS = {
    image: ['Reading file and metadata', 'Measuring noise and smoothness', 'Scoring evidence'],
    video: ['Reading container metadata', 'Sampling and measuring frames', 'Scoring evidence']
  };

  function extOf(name) {
    var m = /\.([a-z0-9]+)$/i.exec(name);
    return m ? m[1].toLowerCase() : '';
  }
  function detectKind(file) {
    var ext = extOf(file.name);
    var keys = Object.keys(KINDS);
    for (var i = 0; i < keys.length; i++) {
      var k = KINDS[keys[i]];
      if (k.mimes.indexOf(file.type) !== -1 || k.exts.indexOf(ext) !== -1) return keys[i];
    }
    return null;
  }
  function formatBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < MB) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1024 * MB) return (n / MB).toFixed(1) + ' MB';
    return (n / (1024 * MB)).toFixed(2) + ' GB';
  }
  function formatDuration(s) {
    if (!isFinite(s)) return 'Unavailable';
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
    var pad = function (v) { return v < 10 ? '0' + v : '' + v; };
    return h ? h + ':' + pad(m) + ':' + pad(sec) : m + ':' + pad(sec);
  }
  function validate(file, allowed) {
    var kind = detectKind(file);
    if (!kind) {
      return { error: 'Unsupported file. Use ' + allowed.map(function (k) { return KINDS[k].names; }).join(' or ') + '.' };
    }
    if (allowed.indexOf(kind) === -1) {
      var other = kind.charAt(0).toUpperCase() + kind.slice(1);
      return { error: 'This page accepts ' + allowed[0] + 's only. Use ' + other + ' Verification for ' + kind + 's.' };
    }
    if (file.size === 0) return { error: 'The file is empty.' };
    if (file.size > KINDS[kind].max) {
      return { error: 'This file is ' + formatBytes(file.size) + '. The maximum for ' + kind + 's is ' + (KINDS[kind].max / MB) + ' MB.' };
    }
    return { kind: kind };
  }

  function loadMeta(kind, url) {
    return new Promise(function (resolve) {
      if (kind === 'image') {
        var im = new Image();
        im.onload = function () { resolve({ width: im.naturalWidth, height: im.naturalHeight }); };
        im.onerror = function () { resolve({}); };
        im.src = url;
      } else {
        var v = document.createElement('video');
        v.preload = 'metadata';
        v.muted = true;
        v.onloadedmetadata = function () { resolve({ width: v.videoWidth, height: v.videoHeight, duration: v.duration }); };
        v.onerror = function () { resolve({}); };
        v.src = url;
      }
      setTimeout(function () { resolve({}); }, 8000);
    });
  }

  function makeMedia(kind, url) {
    var el;
    if (kind === 'image') {
      el = new Image();
      el.alt = 'Uploaded image preview';
    } else {
      el = document.createElement('video');
      el.controls = true;
      el.preload = 'metadata';
      el.setAttribute('playsinline', '');
    }
    el.addEventListener('error', function () {
      var p = document.createElement('p');
      p.className = 'na';
      p.textContent = 'Preview is not available for this file in your browser. Verification still works.';
      if (el.parentNode) el.replaceWith(p);
    });
    el.src = url;
    return el;
  }

  async function sha256(file) {
    try {
      var buf = await file.arrayBuffer();
      var digest = await crypto.subtle.digest('SHA-256', buf);
      return Array.prototype.map.call(new Uint8Array(digest), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    } catch (e) {
      return null;
    }
  }

  /* ------------------------------------------------------------------
     Detection layer
     Runs in the browser. Files are not uploaded anywhere.

     The local analysis looks at evidence that is actually in the file:
       1. Metadata and provenance: generator names, prompt parameters,
          IPTC "trainedAlgorithmicMedia", C2PA Content Credentials.
       2. Capture data: camera make, model and exposure settings (EXIF),
          or device tags in video containers.
       3. Pixel statistics: sensor-style noise versus unusually smooth areas,
          measured at native resolution.
       4. Size profile: dimensions typical of image and video generators.

     Strong evidence (a generator marker) gives a firm result. Weak evidence
     is capped and can only produce a low-confidence result or "Inconclusive".

     To use a trained model instead, set Detector.endpoint to a URL. The page
     then POSTs multipart form data (file, type) and expects JSON:
       { "verdict": "authentic" | "ai" | "unclear",
         "confidence": 0-100,
         "summary": "short explanation",
         "signals": [ { "label": "...", "status": "pass" | "flag" | "na", "note": "..." } ] }
     ------------------------------------------------------------------ */
  var Detector = {
    endpoint: null,

    analyze: async function (job) {
      var raw = this.endpoint ? await this.remote(job) : await localAnalyze(job);
      return normalize(raw);
    },

    remote: async function (job) {
      var body = new FormData();
      body.append('file', job.file);
      body.append('type', job.kind);
      job.onProgress(0.25);
      var res = await fetch(this.endpoint, { method: 'POST', body: body });
      if (!res.ok) throw new Error('The detection service returned an error (' + res.status + ').');
      job.onProgress(1);
      return res.json();
    }
  };

  function normalize(raw) {
    var c = Math.round(Number(raw && raw.confidence));
    var v = raw && (raw.verdict === 'ai' || raw.verdict === 'unclear') ? raw.verdict : 'authentic';
    return {
      verdict: v,
      confidence: Math.max(0, Math.min(100, isNaN(c) ? 0 : c)),
      summary: String((raw && raw.summary) || ''),
      signals: raw && Array.isArray(raw.signals) ? raw.signals : []
    };
  }

  var AI_RE = /stable[ _-]?diffusion|midjourney|dall[-\u00b7 _]?e|openai|firefly|comfyui|"class_type"|ksampler|automatic1111|invokeai|novelai|leonardo\.ai|ideogram|black forest labs|\bflux\.1|sdxl|runwayml|kling ?ai|synthesia|heygen|hailuo|pixverse|google veo|luma ai|dream machine|\bsora\b|trainedAlgorithmicMedia|compositeSynthetic|negative prompt|steps: ?\d+, ?sampler|made with google ai/i;
  var STRONG_RE = /trainedAlgorithmicMedia|compositeSynthetic|negative prompt|steps: ?\d+, ?sampler|made with google ai|"class_type"/i;
  var C2PA_RE = /c2pa|contentauth|content credentials/i;
  var VIDEO_CAM_RE = /com\.apple\.quicktime\.(make|model)|com\.android\.(version|capture\.fps)|\bDJI\b|GoPro|Insta360/;
  var GEN_IMG = ['512x512', '512x768', '768x512', '768x768', '1024x1024', '1024x1792', '1792x1024', '1536x1024', '1024x1536',
    '1344x768', '768x1344', '1152x896', '896x1152', '1216x832', '832x1216', '1408x768', '768x1408', '2048x2048'];
  var GEN_VID = ['1024x576', '576x1024', '832x480', '480x832', '1360x768', '768x1360', '1024x1024', '1280x720', '720x1280'];

  function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // First 2 MB and last 1 MB: where metadata and container atoms live
  async function readBytes(file) {
    var head = new Uint8Array(await file.slice(0, 2 * MB).arrayBuffer());
    if (file.size <= 2 * MB) return head;
    var tail = new Uint8Array(await file.slice(Math.max(2 * MB, file.size - MB)).arrayBuffer());
    var all = new Uint8Array(head.length + tail.length);
    all.set(head); all.set(tail, head.length);
    return all;
  }

  // Printable text runs, like the Unix "strings" tool. Runs of 6+ characters keep random binary from matching.
  function strings(b) {
    var out = [], cur = '';
    for (var i = 0; i < b.length; i++) {
      var c = b[i];
      if (c >= 32 && c < 127) {
        cur += String.fromCharCode(c);
        if (cur.length > 600) { out.push(cur); cur = ''; }
      } else {
        if (cur.length >= 6) out.push(cur);
        cur = '';
      }
    }
    if (cur.length >= 6) out.push(cur);
    return out.join('\n');
  }

  // Locate the EXIF (TIFF) block in a JPEG, PNG or WebP file
  function findTiff(b) {
    var i, L;
    if (b[0] === 0xFF && b[1] === 0xD8) {
      i = 2;
      while (i + 10 < b.length && b[i] === 0xFF) {
        var m = b[i + 1]; L = (b[i + 2] << 8) | b[i + 3];
        if (m === 0xE1 && b[i + 4] === 0x45 && b[i + 5] === 0x78 && b[i + 6] === 0x69 && b[i + 7] === 0x66) return i + 10;
        if (m === 0xDA) break;
        i += 2 + L;
      }
    } else if (b[0] === 0x89 && b[1] === 0x50) {
      i = 8;
      while (i + 12 <= b.length) {
        L = ((b[i] << 24) | (b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3]) >>> 0;
        if (String.fromCharCode(b[i + 4], b[i + 5], b[i + 6], b[i + 7]) === 'eXIf') return i + 8;
        i += 12 + L;
      }
    } else if (b[0] === 0x52 && b[8] === 0x57) {
      i = 12;
      while (i + 8 <= b.length) {
        L = (b[i + 4] | (b[i + 5] << 8) | (b[i + 6] << 16) | (b[i + 7] << 24)) >>> 0;
        if (String.fromCharCode(b[i], b[i + 1], b[i + 2], b[i + 3]) === 'EXIF') {
          return b[i + 8] === 0x45 ? i + 14 : i + 8;
        }
        i += 8 + L + (L & 1);
      }
    }
    return -1;
  }

  function parseExif(b) {
    try {
      var o = findTiff(b);
      if (o < 0) return null;
      var le = b[o] === 0x49;
      var u16 = function (p) { return le ? b[p] | (b[p + 1] << 8) : (b[p] << 8) | b[p + 1]; };
      var u32 = function (p) {
        return (le ? (b[p] | (b[p + 1] << 8) | (b[p + 2] << 16) | (b[p + 3] << 24))
                   : ((b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3])) >>> 0;
      };
      var out = {}, exifPtr = 0;
      var ascii = function (p, n) {
        var s = '';
        for (var i = 0; i < n && p + i < b.length; i++) { if (!b[p + i]) break; s += String.fromCharCode(b[p + i]); }
        return s.trim();
      };
      var ifd = function (p, names) {
        var n = u16(p);
        for (var k = 0; k < n && k < 200; k++) {
          var e = p + 2 + k * 12, tag = u16(e), type = u16(e + 2), cnt = u32(e + 4);
          if (tag === 0x8769) { exifPtr = o + u32(e + 8); continue; }
          var name = names[tag];
          if (!name) continue;
          var vp = (type === 2 && cnt <= 4) ? e + 8 : o + u32(e + 8);
          if (type === 2) out[name] = ascii(vp, cnt);
          else if (type === 3) out[name] = u16(e + 8);
          else if (type === 5) { var d = u32(vp + 4); out[name] = d ? u32(vp) / d : 0; }
        }
      };
      ifd(o + u32(o + 4), { 0x10F: 'make', 0x110: 'model', 0x131: 'software' });
      if (exifPtr) ifd(exifPtr, { 0x829A: 'exposure', 0x829D: 'fnumber', 0x8827: 'iso', 0x9003: 'date', 0x920A: 'focal' });
      return out;
    } catch (e) {
      return null;
    }
  }

  // Noise measured at native resolution: residual after removing the 4-neighbour mean, per 16x16 block
  function blockStds(img, w, h) {
    var d = img.data, g = new Float32Array(w * h), i;
    for (i = 0; i < w * h; i++) g[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
    var out = [];
    for (var y = 1; y + 16 <= h - 1; y += 16) {
      for (var x = 1; x + 16 <= w - 1; x += 16) {
        var s = 0, s2 = 0;
        for (var yy = 0; yy < 16; yy++) {
          var p = (y + yy) * w + x;
          for (var xx = 0; xx < 16; xx++, p++) {
            var r = g[p] - (g[p - 1] + g[p + 1] + g[p - w] + g[p + w]) / 4;
            s += r; s2 += r * r;
          }
        }
        var m = s / 256;
        out.push(Math.sqrt(Math.max(0, s2 / 256 - m * m)));
      }
    }
    return out;
  }
  function summarize(stds) {
    if (stds.length < 8) return null;
    var a = stds.slice().sort(function (x, y) { return x - y; }), low = 0, flat = 0;
    a.forEach(function (v) { if (v < 0.4) low++; if (v < 0.05) flat++; });
    return { floor: a[Math.floor(a.length * 0.1)], plastic: low / a.length, flat: flat / a.length };
  }

  async function imagePixels(file, onP) {
    if (!window.createImageBitmap) return null;
    var bmp;
    try { bmp = await createImageBitmap(file); } catch (e) { return null; }
    try {
      var W = bmp.width, H = bmp.height;
      if (Math.min(W, H) < 96) return null;
      var PS = Math.min(384, W, H);
      var c = document.createElement('canvas'); c.width = c.height = PS;
      var ctx = c.getContext('2d', { willReadFrequently: true });
      if (!ctx) return null;
      var all = [], fr = [0.15, 0.5, 0.85], n = 0;
      for (var a = 0; a < 3; a++) {
        for (var b = 0; b < 3; b++) {
          ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, PS, PS);
          ctx.drawImage(bmp, Math.round((W - PS) * fr[b]), Math.round((H - PS) * fr[a]), PS, PS, 0, 0, PS, PS);
          all = all.concat(blockStds(ctx.getImageData(0, 0, PS, PS), PS, PS));
          onP(++n / 9);
          await sleep(0);
        }
      }
      return summarize(all);
    } finally {
      if (bmp.close) bmp.close();
    }
  }

  function seek(v, t) {
    return new Promise(function (res) {
      var h = function () { v.removeEventListener('seeked', h); res(); };
      v.addEventListener('seeked', h);
      v.currentTime = t;
      setTimeout(res, 3000);
    });
  }

  function videoPixels(url, onP) {
    return new Promise(function (resolve) {
      var v = document.createElement('video');
      v.muted = true; v.preload = 'auto'; v.setAttribute('playsinline', '');
      var done = false;
      function finish(r) { if (done) return; done = true; clearTimeout(timer); v.removeAttribute('src'); v.load(); resolve(r); }
      var timer = setTimeout(function () { finish(null); }, 25000);
      v.onerror = function () { finish(null); };
      v.onloadeddata = async function () {
        try {
          var dur = v.duration, W = v.videoWidth, H = v.videoHeight;
          if (!isFinite(dur) || dur <= 0 || !W || !H || Math.min(W, H) < 96) { finish(null); return; }
          var PS = Math.min(384, W, H);
          var c = document.createElement('canvas'); c.width = c.height = PS;
          var ctx = c.getContext('2d', { willReadFrequently: true });
          var all = [], N = 6;
          for (var i = 0; i < N; i++) {
            await seek(v, dur * (i + 0.5) / N);
            ctx.drawImage(v, Math.round((W - PS) / 2), Math.round((H - PS) / 2), PS, PS, 0, 0, PS, PS);
            all = all.concat(blockStds(ctx.getImageData(0, 0, PS, PS), PS, PS));
            onP((i + 1) / N);
          }
          finish(summarize(all));
        } catch (e) { finish(null); }
      };
      v.src = url;
    });
  }

  async function localAnalyze(job) {
    var kind = job.kind, ev = [], logit = 0, hard = null;
    function add(label, status, note, w) { ev.push({ label: label, status: status, note: note }); logit += w || 0; }

    var bytes = await readBytes(job.file);
    job.onProgress(0.12);
    var meta = (await job.meta) || {};
    var text = strings(bytes);
    var m = AI_RE.exec(text);
    var dims = meta.width && meta.height ? meta.width + 'x' + meta.height : '';
    job.onProgress(0.2);

    // 1. Provenance and metadata
    if (m) {
      hard = { strong: STRONG_RE.test(text), name: m[0] };
      add('Provenance and metadata', 'flag', 'AI generator marker found in the file data: "' + m[0].slice(0, 40) + '".', 6);
    } else if (C2PA_RE.test(text)) {
      add('Provenance and metadata', 'na', 'Content Credentials (C2PA) data is present. It was not cryptographically verified here.', 0);
    } else {
      add('Provenance and metadata', 'pass', 'No generator names, prompt data or synthetic-media tags found.', 0);
    }

    var camLevel = 0;
    if (kind === 'image') {
      // 2. Camera data
      var ex = parseExif(bytes), sw = ex && ex.software ? ' Software: ' + ex.software.slice(0, 40) + '.' : '';
      if (ex && ex.make && ex.model && (ex.exposure || ex.iso || ex.fnumber)) {
        camLevel = 2;
        add('Camera data', 'pass', 'Camera ' + (ex.make + ' ' + ex.model).slice(0, 48) + ' with exposure settings recorded.' + sw, -2.5);
      } else if (ex && (ex.make || ex.model)) {
        camLevel = 1;
        add('Camera data', 'pass', 'Camera make or model is recorded, without full exposure settings.' + sw, -1);
      } else {
        add('Camera data', 'na', 'No camera make, model or exposure data. Screenshots, web downloads and generated images all look like this.' + sw, 0.4);
      }
      // 3. Dimensions
      if (!camLevel && dims && GEN_IMG.indexOf(dims) !== -1) {
        add('Image dimensions', 'flag', meta.width + ' \u00d7 ' + meta.height + ' px is a common generator output size and no camera data is present.', 1.2);
      } else if (!camLevel && meta.width && meta.width % 64 === 0 && meta.height % 64 === 0 && Math.min(meta.width, meta.height) >= 512) {
        add('Image dimensions', 'na', 'Both sides are multiples of 64, which generators favor. Not conclusive on its own.', 0.4);
      } else {
        add('Image dimensions', 'pass', 'Dimensions do not match a known generator size.', 0);
      }
      // 4. Pixels
      job.onProgress(0.3);
      var px = await imagePixels(job.file, function (f) { job.onProgress(0.3 + 0.6 * f); });
      addPixels(px);
    } else {
      var cam = VIDEO_CAM_RE.test(text);
      if (cam) { camLevel = 2; add('Recording device', 'pass', 'Container carries phone or camera recording tags.', -2); }
      else add('Recording device', 'na', 'No device tags in the container. Edited, exported and generated clips all look like this.', 0.3);
      var short = meta.duration && meta.duration <= 12;
      if (!cam && short && GEN_VID.indexOf(dims) !== -1) {
        add('Clip profile', 'na', 'Short clip at a resolution common to video generators. Not conclusive on its own.', 0.5);
      } else {
        add('Clip profile', 'pass', 'Length and resolution do not stand out.', 0);
      }
      job.onProgress(0.3);
      var vpx = await videoPixels(job.url, function (f) { job.onProgress(0.3 + 0.6 * f); });
      addPixels(vpx);
    }

    function addPixels(p) {
      var label = kind === 'video' ? 'Frame noise' : 'Noise and smoothness';
      if (!p) add(label, 'na', 'Pixel data could not be read for this file.', 0);
      else if (p.flat >= 0.3) add(label, 'na', 'Large perfectly flat areas suggest a screenshot or graphic, which this check cannot judge.', 0);
      else if (p.floor < 0.3 && p.plastic > 0.35) add(label, 'flag', 'Large areas are unusually smooth and free of sensor noise.', 0.9);
      else if (p.floor >= 0.8 && p.plastic < 0.1) add(label, 'pass', 'Fine sensor-style noise is present across flat areas.', -0.7);
      else add(label, 'pass', 'Noise level is within the range seen in ordinary captures.', 0);
    }

    job.onProgress(0.97);
    await sleep(350);

    var verdict, conf, summary;
    var noun = kind === 'video' ? 'clip' : 'image';
    if (hard) {
      verdict = 'ai'; conf = hard.strong ? 97 : 92;
      summary = 'The file contains a marker from an AI generator or editor ("' + hard.name.slice(0, 40) + '"). The ' + noun + ' was generated or edited with AI tools.';
    } else if (logit >= 1.2) {
      verdict = 'ai'; conf = Math.min(80, Math.round(100 * sigmoid(logit)));
      summary = 'No definitive marker was found, but missing capture data and pixel patterns resemble generated media. Treat this as a lead and check the source.';
    } else if (logit <= -1) {
      verdict = 'authentic'; conf = Math.min(90, Math.round(100 * sigmoid(-logit)));
      summary = 'Capture data is present and no generator markers were found. Metadata can be edited, so this supports authenticity without proving it.';
    } else {
      verdict = 'unclear'; conf = Math.round(100 * sigmoid(Math.abs(logit)));
      summary = 'The evidence is missing or mixed. Stripped metadata and re-compression make ' + noun + 's hard to judge. Check the original source.';
    }
    job.onProgress(1);
    return { verdict: verdict, confidence: conf, summary: summary, signals: ev };
  }


  /* ------------------------------------------------------------------
     Verifier component
     ------------------------------------------------------------------ */
  function mount(host, key, allowed) {
    host.appendChild(document.getElementById('verifier-tpl').content.cloneNode(true));
    var $ = function (role) { return host.querySelector('[data-role="' + role + '"]'); };
    var stage = function (name) { return host.querySelector('[data-stage="' + name + '"]'); };

    var el = {
      status: $('status'), drop: $('drop'), dropTitle: $('dropTitle'), input: $('input'),
      preview: $('preview'), media: $('media'), name: $('name'), remove: $('remove'),
      formats: $('formats'), error: $('error'), verify: $('verify'),
      busyTitle: $('busyTitle'), progress: $('progress'), progressWrap: $('progressWrap'), steps: $('steps'),
      rMedia: $('rMedia'), rName: $('rName'), info: $('info'), verdictPanel: $('verdictPanel'),
      verdict: $('verdict'), conf: $('conf'), meter: $('meter'), meterWrap: $('meterWrap'),
      summary: $('summary'), note: $('note'), signals: $('signals'), again: $('again')
    };

    // Copy that depends on which kinds this page accepts
    el.input.id = key + '-file';
    el.input.setAttribute('aria-label', 'Choose a file to verify');
    el.input.accept = allowed.reduce(function (acc, k) {
      return acc.concat(KINDS[k].mimes, KINDS[k].exts.map(function (e) { return '.' + e; }));
    }, []).join(',');
    if (allowed.length === 2) {
      el.dropTitle.textContent = 'Drop an image or video here';
      el.formats.textContent = 'Images: ' + KINDS.image.names + ', up to ' + (KINDS.image.max / MB) + ' MB. Videos: ' + KINDS.video.names + ', up to ' + (KINDS.video.max / MB) + ' MB.';
    } else {
      var k = KINDS[allowed[0]];
      el.dropTitle.textContent = 'Drop ' + (allowed[0] === 'image' ? 'an image' : 'a video') + ' here';
      el.formats.textContent = 'Supported formats: ' + k.names + '. Maximum file size: ' + (k.max / MB) + ' MB.';
    }
    el.drop.setAttribute('aria-label', el.dropTitle.textContent + ' or press Enter to browse files');

    var file = null, kind = null, url = null, metaPromise = null, runId = 0;

    function setStatus(text, tone) {
      el.status.textContent = text;
      if (tone) el.status.setAttribute('data-tone', tone); else el.status.removeAttribute('data-tone');
    }
    function showStage(name) {
      ['input', 'busy', 'result'].forEach(function (n) { stage(n).hidden = n !== name; });
    }
    function showError(msg) {
      el.error.textContent = msg || '';
      el.error.hidden = !msg;
    }
    function releaseUrl() {
      if (url) { URL.revokeObjectURL(url); url = null; }
    }

    function reset() {
      runId++;
      releaseUrl();
      file = null; kind = null; metaPromise = null;
      el.media.textContent = '';
      el.rMedia.textContent = '';
      el.preview.hidden = true;
      el.drop.hidden = false;
      el.verify.disabled = true;
      showError('');
      showStage('input');
      setStatus('No file selected');
    }

    function accept(f) {
      var v = validate(f, allowed);
      if (v.error) { showError(v.error); return; }
      showError('');
      releaseUrl();
      file = f; kind = v.kind;
      url = URL.createObjectURL(f);
      metaPromise = loadMeta(kind, url);
      el.media.textContent = '';
      el.media.appendChild(makeMedia(kind, url));
      el.name.textContent = f.name + '  ·  ' + formatBytes(f.size);
      el.name.title = f.name;
      el.drop.hidden = true;
      el.preview.hidden = false;
      el.verify.disabled = false;
      setStatus('Ready to verify', 'accent');
    }

    // Choosing and dropping files
    el.drop.addEventListener('click', function () { el.input.click(); });
    el.drop.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.input.click(); }
    });
    el.input.addEventListener('change', function () {
      if (el.input.files && el.input.files[0]) accept(el.input.files[0]);
      el.input.value = '';
    });
    ['dragenter', 'dragover'].forEach(function (t) {
      el.drop.addEventListener(t, function (e) { e.preventDefault(); el.drop.setAttribute('data-drag', ''); });
    });
    ['dragleave', 'drop'].forEach(function (t) {
      el.drop.addEventListener(t, function (e) { e.preventDefault(); el.drop.removeAttribute('data-drag'); });
    });
    el.drop.addEventListener('drop', function (e) {
      var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) accept(f);
    });
    el.remove.addEventListener('click', reset);
    el.again.addEventListener('click', reset);

    // Analysis
    function updateProgress(f) {
      el.progress.style.width = Math.round(f * 100) + '%';
      el.progressWrap.setAttribute('aria-valuenow', Math.round(f * 100));
      var n = STEPS[kind].length;
      var current = Math.min(n - 1, Math.floor(f * n));
      Array.prototype.forEach.call(el.steps.children, function (li, i) {
        var s = f >= 1 || i < current ? 'done' : i === current ? 'run' : 'wait';
        li.setAttribute('data-s', s);
        li.lastChild.textContent = s === 'done' ? 'Done' : s === 'run' ? 'Running' : 'Queued';
      });
    }

    async function run() {
      if (!file) return;
      var id = ++runId;
      var media = el.media.querySelector('video');
      if (media) media.pause();
      showError('');
      el.busyTitle.textContent = 'Analyzing ' + file.name;
      el.steps.textContent = '';
      STEPS[kind].forEach(function (label) {
        var li = document.createElement('li');
        var a = document.createElement('span'); a.textContent = label;
        var b = document.createElement('span'); b.textContent = 'Queued';
        li.appendChild(a); li.appendChild(b);
        el.steps.appendChild(li);
      });
      updateProgress(0);
      showStage('busy');
      setStatus('Analyzing', 'accent');

      try {
        var out = await Promise.all([
          metaPromise,
          sha256(file),
          Detector.analyze({ file: file, kind: kind, url: url, meta: metaPromise, onProgress: function (f) { if (id === runId) updateProgress(f); } })
        ]);
        if (id !== runId) return;
        renderResult(out[2], out[0] || {}, out[1]);
      } catch (err) {
        if (id !== runId) return;
        showStage('input');
        setStatus('Ready to verify', 'accent');
        showError((err && err.message) || 'Analysis failed. Try again.');
      }
    }
    el.verify.addEventListener('click', run);

    function row(label, value, title) {
      var dt = document.createElement('dt'); dt.textContent = label;
      var dd = document.createElement('dd'); dd.textContent = value;
      if (title) dd.title = title;
      el.info.appendChild(dt); el.info.appendChild(dd);
    }

    function renderResult(res, meta, hash) {
      el.rMedia.textContent = '';
      el.rMedia.appendChild(makeMedia(kind, url));
      el.rName.textContent = file.name;
      el.rName.title = file.name;

      el.info.textContent = '';
      row('File name', file.name);
      row('Type', TYPE_LABELS[extOf(file.name)] || file.type || 'Unknown');
      row('Size', formatBytes(file.size));
      row('Resolution', meta.width && meta.height ? meta.width + ' × ' + meta.height + ' px' : 'Unavailable');
      if (kind === 'video') row('Duration', formatDuration(meta.duration));
      row('SHA-256', hash || 'Unavailable');
      row('Analyzed', new Date().toLocaleString(undefined, { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }));

      var ai = res.verdict === 'ai';
      el.verdictPanel.setAttribute('data-verdict', res.verdict);
      el.verdict.textContent = ai ? 'Likely AI Generated' : res.verdict === 'unclear' ? 'Inconclusive' : 'Likely Authentic';
      el.conf.textContent = res.confidence + '%';
      el.meterWrap.setAttribute('aria-label', 'Confidence ' + res.confidence + ' percent');
      el.meter.style.width = '0';
      requestAnimationFrame(function () { requestAnimationFrame(function () { el.meter.style.width = res.confidence + '%'; }); });
      el.summary.textContent = res.summary;
      el.note.hidden = res.verdict !== 'unclear' && res.confidence >= 65;
      el.note.textContent = 'Confidence is low. Treat this result as inconclusive and check the original source.';

      el.signals.textContent = '';
      res.signals.forEach(function (s) {
        var li = document.createElement('li');
        var text = document.createElement('div');
        var t = document.createElement('p'); t.className = 'sig-t'; t.textContent = s.label;
        var n = document.createElement('p'); n.className = 'sig-n'; n.textContent = s.note || '';
        text.appendChild(t); text.appendChild(n);
        var pill = document.createElement('span');
        pill.className = 'pill';
        var flagged = s.status === 'flag';
        var na = s.status === 'na';
        if (!na) pill.setAttribute('data-tone', flagged ? 'warn' : 'ok');
        pill.textContent = flagged ? 'Flagged' : na ? 'No data' : 'Normal';
        li.appendChild(text); li.appendChild(pill);
        el.signals.appendChild(li);
      });

      setStatus('Complete');
      showStage('result');
    }

    reset();
  }

  mount(document.querySelector('[data-mount="image"]'), 'image', ['image']);
  mount(document.querySelector('[data-mount="video"]'), 'video', ['video']);

  // A file dropped outside a drop area must not navigate away from the page
  ['dragover', 'drop'].forEach(function (t) {
    window.addEventListener(t, function (e) { e.preventDefault(); });
  });

  /* ------------------------------------------------------------------
     Navigation
     ------------------------------------------------------------------ */
  var VIEWS = ['home', 'image', 'video', 'about'];
  function show(view) {
    if (VIEWS.indexOf(view) === -1) view = 'home';
    document.querySelectorAll('[data-view]').forEach(function (s) { s.hidden = s.getAttribute('data-view') !== view; });
    document.querySelectorAll('.nav a').forEach(function (a) {
      if (a.getAttribute('data-nav') === view) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    document.querySelectorAll('video').forEach(function (v) { v.pause(); });
    window.scrollTo(0, 0);
  }
  document.querySelectorAll('[data-nav]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var v = a.getAttribute('data-nav');
      show(v);
      try { history.replaceState(null, '', '#' + v); } catch (err) { /* hash update is optional */ }
    });
  });
  window.addEventListener('hashchange', function () { show(location.hash.slice(1)); });
  show(location.hash.slice(1));
})();
